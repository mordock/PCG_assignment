﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace InGame {
    public class Obstruction : MonoBehaviour
    {
        public bool canBeOpened = false;
    }
}